﻿const en = {
  lblLanguage: "عربى",
  lblProducts: "Products",
};

const ar = {
  lblLanguage: "English",
  lblProducts: "منتجات",
};

const appLang = {
  en: { ...en },
  ar: { ...ar },
};
