﻿




var host= window.location.protocol + "//" + window.location.host;


var appBaseUrl = host + "/";




